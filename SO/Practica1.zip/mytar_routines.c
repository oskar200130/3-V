#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

extern char *use;

/** Copy nBytes bytes from the origin file to the destination file.
 *
 * origin: pointer to the FILE descriptor associated with the origin file
 * destination:  pointer to the FILE descriptor associated with the destination file
 * nBytes: number of bytes to copy
 *
 * Returns the number of bytes actually copied or -1 if an error occured.
 */
int copynFile(FILE * origin, FILE * destination, int nBytes)
{
	//Contador de tamano
	int nCopy = 0;
	//Lee byte a byte
	int c = 0;
	//Mientras no hayamos leido todos los bytes pedidos o no lleguemos al final del archivo
	while(nCopy < nBytes && (c = getc(origin)) != EOF){
		//Copia el c leido de origin en destination
		putc((unsigned char) c, destination);
		nCopy++;
	}

	return nCopy;
}

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor 
 * 
 * The loadstr() function must allocate memory from the heap to store 
 * the contents of the string read from the FILE. 
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc()) 
 * 
 * Returns: !=NULL if success, NULL if error
 */
char* loadstr(FILE * file)
{
	int n, size = 0;
	char* buf; //cadena
	//Leemos hasta llegar al final o encontrar fin de linea
	do{
		n = getc(file);
		size++;
	}while((n != (int)'\0') && (n != EOF));

	//Si es fin de archivo
	if(n == EOF)
		return NULL;
	//Si no se puede reservar memoria
	if((buf = (char*)malloc(size)) == NULL)
		return NULL;
	
	//Volvemos al inicio del string
	fseek(file, -size, SEEK_CUR);
	//Lo cargamos en el buffer
	fread(buf, 1, size, file);

	return buf;
}

/** Read tarball header and store it in memory.
 *
 * tarFile: pointer to the tarball's FILE descriptor 
 * nFiles: output parameter. Used to return the number 
 * of files stored in the tarball archive (first 4 bytes of the header).
 *
 * On success it returns the starting memory address of an array that stores 
 * the (name,size) pairs read from the tar file. Upon failure, the function returns NULL.
 */
stHeaderEntry* readHeader(FILE * tarFile, int *nFiles)
{
	int i, j;
	stHeaderEntry* header;

	//Leemos el nº de archivos que tiene
	fread(nFiles, sizeof(int), 1, tarFile);

	if((header = (stHeaderEntry*) malloc(sizeof(stHeaderEntry) * (*nFiles)))){
		perror("Error al alojar memoria para devolver la cabecera");
		fclose(tarFile);
		return NULL;
	}

	for(i = 0; i < *nFiles; i++){
		//Cargamos el nombre
		if((header[i].name = loadstr(tarFile)) == NULL){
			//Si falla, liberamos memoria
			for(j = 0; j < *nFiles; j++){
				free(header[i].name);
			}
			free(header);
			fclose(tarFile);
			return NULL;
		}
		//Leemos en el tamaño de header...size, del tamaño de header...size, 1 vez, de tarfile
		//Es justo lo que va despues del nombre
		fread(&header[i].size, sizeof(header[i].size), 1, tarFile);
	}

	return header;
}

/** Creates a tarball archive 
 *
 * nfiles: number of files to be stored in the tarball
 * filenames: array with the path names of the files to be included in the tarball
 * tarname: name of the tarball archive
 * 
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First reserve room in the file to store the tarball header.
 * Move the file's position indicator to the data section (skip the header)
 * and dump the contents of the source files (one by one) in the tarball archive. 
 * At the same time, build the representation of the tarball header in memory.
 * Finally, rewind the file's position indicator, write the number of files as well as 
 * the (file name,file size) pairs in the tar archive.
 *
 * Important reminder: to calculate the room needed for the header, a simple sizeof 
 * of stHeaderEntry will not work. Bear in mind that, on disk, file names found in (name,size) 
 * pairs occupy strlen(name)+1 bytes.
 *
 */
int createTar(int nFiles, char *fileNames[], char tarName[])
{
	int i, j;

	FILE* tarFile, *inputFile;

	stHeaderEntry* header;
	unsigned int headerSize;

	//Si el nº de archivos es nulo, se devuelve error
	if(nFiles <= 0){
		//Dónde pintar, qué quiero pintar
		fprintf(stderr, "%s", use);
		return EXIT_FAILURE;
	}
	//Si abrir el archivo de escritura (el archivo donde se escribe lo que vamos a unir) da error 
	if((tarFile = fopen(tarName, "wx")) == NULL){
		fprintf(stderr, "El archivo mytar %s podria no haberse abierto: ", tarName);
		perror(NULL);
		return EXIT_FAILURE;
	}
	//Con malloc reservo memoria en memoria dinámica (el tamaño de headerEntry * el numero de archivos a unir)
	if((header = malloc(sizeof(stHeaderEntry)* nFiles)) == NULL){
		perror("Error al alojar memoria en la cabecera del arhivo mtar");
		fclose(tarFile);
		remove(tarName);
		return EXIT_FAILURE;
	}
	//Con el array de headers ya bien creado
	//El tamaño del header será como máximo el tamaño maximo de int (int nFiles)
	headerSize = sizeof(int);
	for(i = 0; i < nFiles; i++){
		
		int nameSize = strlen(fileNames[i] + 1); // el +1 indica el final del array "/0" que no contempla strlen

		//Reservamos la memoria del nombre
		header[i].name = (char*) malloc(nameSize);
		if(header[i].name == NULL){
			perror("Error al crear el tarball, nombre incorrecto");
			fclose(tarFile);
			remove(tarName);
			//Hay que deshacer todo lo que hicimos en caso de error
			for(j = 0; j < i; j++){
				free(header[j].name);
			}
			//Y liberar la memoria
			free(header);
			return EXIT_FAILURE;
		}

		//Copiamos los nombres
		strcpy(header[i].name, fileNames[i]);
		printf("%s", header[i].name);
		headerSize += nameSize + sizeof(header->size);
	}
	//Lo usamos para avanzar por un fichero.
	//Queremos avanzar hasta despues de la cabecera, para copiar los datos a partir de ahi
	fseek(tarFile, headerSize, SEEK_SET);

	//Introducimos los archivos de forma secuencial a partir de los headers
	for(i = 0; i < nFiles; i++){
		//Abrimos el archivo en modo lectura ("r")
		if((inputFile = fopen(fileNames[i], "r")) == NULL){
			fprintf(stderr, "No es posible abrir el archivo de entrada %s: \n", fileNames[i]);
			perror(NULL);
			//Cerramos el tarFile
			fclose(tarFile);
			remove(tarName);
			//Hay que deshacer todo lo que hicimos en caso de error
			for(j = 0; j < i; j++){
				free(header[j].name);
			}
			//Y liberar la memoria
			free(header);
			//Y cerramos el archivo a copiar
			fclose(inputFile);
			return EXIT_FAILURE;
		}
		//Copiamos los datos
		header[i].size = copynFile(inputFile, tarFile, INT_MAX);
		//Y cerramos el archivo que ya no necesitamos
		fclose(inputFile);
	}
	//Volvemos al principio del tarFile, donde aun no hemos copiado la cabecera
	rewind(tarFile);
	//Quiero escribir en el archivo tarFile, 1 vez, el tamaño de int, nFiles
	//Es decir, escribimos el nº de archivos del tar
	fwrite(&nFiles, sizeof(int), 1, tarFile);
	//Ahora escribimos la info de los headers (nombre y tamaño)
	for(i = 0; i < nFiles; i++){
		fwrite(header[i].name, 1, strlen(header[i].name) + 1, tarFile);
		fwrite(&header[i].size, sizeof(header[i].size), 1, tarFile);
	}

	fprintf(stdout, "El archivo mtar ha sido creado exitosamente\n");
	
	//Y ahora liberamos la memoria reservada
	for(j = 0; j < i; j++){
		free(header[j].name);
	}
	//Y liberar la memoria
	free(header);

	//Y cerramos el archivo porque ya hemos terminado
	fclose(tarFile);

	return EXIT_SUCCESS;
}

/** Extract files stored in a tarball archive
 *
 * tarName: tarball's pathname
 *
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First load the tarball's header into memory.
 * After reading the header, the file position indicator will be located at the 
 * tarball's data section. By using information from the 
 * header --number of files and (file name, file size) pairs--, extract files 
 * stored in the data section of the tarball.
 *
 */
int extractTar(char tarName[])
{
	stHeaderEntry* header = NULL;
	int nFiles, i = 0, copy = 0;
	FILE* tarFile = NULL;
	//Si abrir el archivo de lectura("r") da error 
	if((tarFile = fopen(tarName, "r")) == NULL){
		fprintf(stderr, "El archivo mytar %s podria no haberse abierto: ", tarName);
		perror(NULL);
		return EXIT_FAILURE;
	}

	//Ahora leemos el header
	header = readHeader(tarFile, &nFiles);
		
	for(i = 0; i < nFiles; ++i){
		//Creamos el archivo nuevo en modo escritura ('w')
		FILE* newArch = fopen(header[i].name, "w");
		//Si no podemos crearlo, error
		if(newArch == NULL){
			printf("El fichero %s no ha podido abrirse", header[i].name);
			for(i = 0; i < nFiles; i++){
				free(header[i].name);
			}
			//Y liberar la memoria
			free(header);
			fclose(tarFile);
			return EXIT_FAILURE;
		}
		//Una vez creado, se copian los datos del tarFile en él
		copy = copynFile(tarFile, newArch, header[i].size);
		//Si falla la copia, error
		if(copy == -1){
			printf("El fichero no pudo copiarse");
			//Y liberar la memoria
			for(i = 0; i < nFiles; i++){
				free(header[i].name);
			}
			free(header);
			fclose(tarFile);
			return  EXIT_FAILURE;
		}
		//Cerramos el nuevo archivo
		fclose(newArch);
	}
	//Ya acabamos y liberamnos memoria
	for(i = 0; i < nFiles; i++){
		free(header[i].name);
	}
	free(header);
	fclose(tarFile);

	return EXIT_SUCCESS;
}
