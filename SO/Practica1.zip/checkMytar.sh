#!/bin/bash
#chmod +x checkMytar.sh         ./checkMytar.sh 
#Esto para ejecutar
#tar -c -f todosJuntos doc1 doc2 doc3 doc4

# 1. Comprobará que el programa mytar está en el directorio actual y que es ejecutable. En
# caso contrario mostrará un mensaje informativo por pantalla y terminará.

# 2. Comprobará si existe un directorio tmp dentro del directorio actual. Si existe lo borrará,
# incluyendo todo lo que haya dentro de él (mirar la opción -r del comando rm).

# 3. Creará un nuevo directorio temporal tmp dentro del directorio actual y cambiará a este
# directorio.

# 4. Creará tres ficheros (dentro del directorio):
# file1.txt: con el contenido “Hello world!”, utilizando la orden echo y redirigiendo la salida al fichero.
# file2.txt: con una copia de las 10 primeras líneas del fichero /etc/passwd. Se
# hace fácil utilizando el programa head y redirigiendo la salida al fichero.
# file3.dat: con un contenido binario aleatorio de 1024 bytes, tomado del dispositivo /dev/urandom. De nuevo conviene utilizar head con la opción -c.

# 5. Invocará el programa mytar que hemos desarrollado, para crear un fichero filetar.mtar
# con el contenido de los tres ficheros anteriores.

# 6. Creará un directorio out (dentro del directorio actual, que debe ser tmp) y copiará el
# fichero filetar.mtar al nuevo directorio.

# 7. Cambiará al directorio out y ejecutará el programa mytar para extraer el contenido del
# tarball.

# 8. Usará el programa diff para comparar los fichero extraídos con los originales, que estarán en el directorio anterior (..).

# 9. Si los tres ficheros extraídos son iguales que los originales, volverá al directorio original
# (../..), mostrará el mensaje “Correct” por pantalla y devolverá 0. Si hay algún error,
# volverá al directorio original, mostrará un mensaje descriptivo por pantalla y devolverá
# 1.

#Apartado 1
if [ ! -e mytar ] ; then
    echo "”mytar no existe”"
    exit 1
fi

if [ ! -x mytar ] ; then
    echo "mytar no es ejecutable"
    exit 1
fi

#Apartado 2
if [ -e temp ] ; then
    rm -r temp
    #echo "borrado de temp y subdirectorios"
fi

#Apartado 3
mkdir -p -- "temp"
#echo "creado temp"

cd temp

#Apartado 4
echo “Hello world!” > file1.txt

head /etc/passwd > file2.txt

head  -c1024 /dev/urandom > file3.dat

#Apartado 5
tar -cf filetar.mtar file1.txt file2.txt file3.dat

#Apartado 6
mkdir -p -- "out"

cp filetar.mtar out

#Apartado 7
cd out

tar -xf filetar.mtar

#Apartado 8

DIFF=$(diff file1.txt ../file1.txt)
if [ "$DIFF" != "" ] 
then
    cd -
    echo "The directory was modified"
    exit 1
fi
DIFF=$(diff file2.txt ../file2.txt)
if [ "$DIFF" != "" ] 
then
    cd -
    echo "The directory was modified"
    exit 1
fi
DIFF=$(diff file3.dat ../file3.dat)
if [ "$DIFF" != "" ] 
then
    cd -
    echo "The directory was modified"
    exit 1
fi
#Apartado 9
cd -
echo "Correct"
exit 0